# WASSCE Success Hub

Starter full-stack project for a WASSCE learning platform.

## Included
- Next.js frontend
- Student dashboard
- Subject catalogue
- Quiz API
- Study planner
- Prisma database schema
- Authentication-ready API structure

## Run locally
1. Install Node.js 20+
2. Copy `.env.example` to `.env`
3. Run `npm install`
4. Run `npx prisma generate`
5. Run `npm run dev`

Then open http://localhost:3000
