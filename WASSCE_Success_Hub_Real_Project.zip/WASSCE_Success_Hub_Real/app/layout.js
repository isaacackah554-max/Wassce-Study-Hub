import './globals.css';
export const metadata={title:'WASSCE Success Hub',description:'Learn. Practice. Compete. Succeed.'};
export default function RootLayout({children}){return <html lang="en"><body>{children}</body></html>}