'use client';
import {useState} from 'react';
const subjects=['Core Mathematics','Biology','Physics','Chemistry','English','Social Studies','ADF','Add Maths'];
export default function Home(){
 const [dark,setDark]=useState(false); const [tasks,setTasks]=useState([]); const [task,setTask]=useState('');
 const add=()=>{if(task.trim()){setTasks([...tasks,task]);setTask('')}};
 return <main className={dark?'dark':''}>
  <nav><b>🎓 WASSCE Success Hub</b><div><a href="#learn">Learn</a><a href="#quiz">Quiz</a><a href="#planner">Planner</a><button onClick={()=>setDark(!dark)}>🌙</button></div></nav>
  <header><div><p className="badge">GHANA • WASSCE PREPARATION</p><h1>Pass WASSCE.<br/>Build Your Future.</h1><p>Lessons, quizzes, study planning and progress tracking in one learning platform.</p><button onClick={()=>document.querySelector('#learn').scrollIntoView({behavior:'smooth'})}>Start Learning →</button></div></header>
  <section className="stats"><div><b>8+</b><span>Subjects</span></div><div><b>1000+</b><span>Questions planned</span></div><div><b>24/7</b><span>Learning</span></div></section>
  <section id="learn"><h2>📚 Explore Subjects</h2><div className="grid">{subjects.map((s,i)=><article className="card" key={s}><div className="icon">{['🔢','🧬','⚡','🧪','📖','🌍','🎨','➗'][i]}</div><h3>{s}</h3><p>Lessons, practice and revision resources.</p><button onClick={()=>alert(s+' content will be loaded from the database.')}>Study</button></article>)}</div></section>
  <section id="quiz"><h2>🧠 Quick Quiz</h2><article className="quiz"><h3>What is 5 × 6?</h3><button onClick={()=>alert('Try again!')}>25</button><button onClick={()=>alert('Correct! 🎉')}>30</button><button onClick={()=>alert('Try again!')}>35</button></article></section>
  <section id="planner"><h2>📅 My Study Planner</h2><div className="planner"><input value={task} onChange={e=>setTask(e.target.value)} placeholder="e.g. Study Biology for 1 hour"/><button onClick={add}>Add Task</button>{tasks.map((t,i)=><p className="task" key={i}>📚 {t}<button onClick={()=>setTasks(tasks.filter((_,x)=>x!==i)}>✓ Done</button></p>)}</div></section>
  <section className="premium"><h2>⭐ Premium Learning</h2><p>Advanced quizzes, mock exams, analytics and premium resources.</p><button onClick={()=>alert('Payment integration comes after deployment and business setup.')}>Explore Premium</button></section>
  <footer>© 2026 WASSCE Success Hub • Learn. Practice. Compete. Succeed.</footer>
 </main>
}